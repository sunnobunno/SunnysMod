# YIPPEE MOD
Changes the Hoarding Bug chitter SFX to the yippee-tbh sound. That's it.

# Installation
1. Ensure BepInEx and LC_API are installed. Run the game at least once with these mods installed the generate the needed files/folders.
2. Extract the BepInEx folder in the download into the root of the Lethal Company game folder.

This results in the YippeeMod.dll being places in the plugins folder and the yippeesound file being placed in the Bundles folder.

# Preview
See the linked video for a preview of the mod: https://youtu.be/Ri1Kwk8addk